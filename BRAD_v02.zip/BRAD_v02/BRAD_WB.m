function varargout = BRAD_WB(varargin)
% BRAD_WB MATLAB code for BRAD_WB.fig
%      BRAD_WB, by itself, creates a new BRAD_WB or raises the existing
%      singleton*.
%
%      H = BRAD_WB returns the handle to a new BRAD_WB or the handle to
%      the existing singleton*.
%
%      BRAD_WB('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BRAD_WB.M with the given input arguments.
%
%      BRAD_WB('Property','Value',...) creates a new BRAD_WB or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before BRAD_WB_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to BRAD_WB_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help BRAD_WB

% Last Modified by GUIDE v2.5 26-Dec-2019 00:21:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @BRAD_WB_OpeningFcn, ...
                   'gui_OutputFcn',  @BRAD_WB_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before BRAD_WB is made visible.
function BRAD_WB_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to BRAD_WB (see VARARGIN)

% Choose default command line output for BRAD_WB
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes BRAD_WB wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = BRAD_WB_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbuttonCalc.
function pushbuttonCalc_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonCalc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
calculateForBrainLevel(hObject, eventdata, handles);
saveWholeBrainLevel(hObject, eventdata, handles);

% --- Executes on selection change in popupmenuDecMethod.
function popupmenuDecMethod_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuDecMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenuDecMethod contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuDecMethod
global method;
str = get(handles.popupmenuDecMethod,'String');
val = get(handles.popupmenuDecMethod,'Value');
method = str{val};


% --- Executes during object creation, after setting all properties.
function popupmenuDecMethod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuDecMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenuSC.
function popupmenuSC_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenuSC contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuSC

global SC;
str = get(handles.popupmenuSC,'String');
val = get(handles.popupmenuSC,'Value');
SC = str{val};


% --- Executes during object creation, after setting all properties.
function popupmenuSC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuSC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbuttonImpData.
function pushbuttonImpData_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global import;
global parameter;
global wholeBrain;

loadFolders(hObject, eventdata, handles);

pathname = uigetdir(pwd, 'Select folder with .nii:');
addpath(pathname);
import.pathname.wholeBrain = pathname;
set(handles.textImport, 'String', pathname);

loadWholeBrainData(hObject, eventdata, handles);
loadingParameters(hObject, eventdata, handles);
parameter.maxIteration = 4*max(size(wholeBrain));



function loadingParameters(hObject, eventdata, handles)

global parameter;

parameter = usualParameters;





% --- Executes on button press in pushbuttonImpMask.
function pushbuttonImpMask_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImpMask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


global import;

loadFolders(hObject, eventdata, handles);

[filename pathname] = uigetfile({'*.nii'}, 'Select gray-matter mask:');
addpath(pathname);
import.fpath.mask = strcat(pathname, filename);
import.file.mask = filename;
set(handles.textMask, 'String', import.file.mask);

loadMask(hObject, eventdata, handles);




% --- Executes on button press in pushbuttonImprHRF.
function pushbuttonImprHRF_Callback(hObject, eventdata, handles)
% hObject    handle to pushbuttonImprHRF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global import;
global parameter;
global hrf;
global TR;

if get(handles.checkboxDefKern,'Value') == get(handles.checkboxDefKern,'Max')
    TR = str2double(handles.editRT.String);
    hrf = spm_hrf(TR);
    set(handles.textHRF, 'String', ['Generated SPM HRF, RT: ' handles.editRT.String]);
else
    [filename pathname] = uigetfile({'*.csv'}, 'Select file (HRF)');
    addpath(pathname);
    import.fpath.HRf = strcat(pathname, filename);
    import.file.HRf = filename;

    hrf = parameter.constForHRF*load(import.file.HRf);
    set(handles.textHRF, 'String', import.file.HRf);
end;




function loadFolders(hObject, eventdata, handles)
%{
    Initialization.
%}

addpath('Functions');
addpath('Functions/Deconvolution');
addpath('Functions/Technical');
addpath('Functions/PD_pursuit');
addpath('Functions/Filtering');

addpath('Input');
addpath('Input/HRF');
addpath('Input/Time series');
addpath('Input/Spectrum');



function loadWholeBrainData(hObject, eventdata, handles)
%{
    Load data: .mat-file with 4D array (3D+time) with name 'wholeBrain'
%}

global import;
global wholeBrain;

global head;
h = waitbar(0,'Loading the data. Please wait...');
%{
% get the name of variable inside the .mat file
tt = whos('-file',import.fpath.wholeBrain);
% read this variable (4-D matrix)
varTMP = load(import.fpath.wholeBrain,tt.name); % from here we get 'wholeBrain'
% save 4-D matrix into 'wholeBrain' variable
wholeBrain = varTMP.(tt.name);
%}

% wB_head=spm_vol(import.fpath.wholeBrain); 
% wholeBrain=spm_read_vols(wB_head); % vol_mat=data from .nii converted to double

    sub_path = import.pathname.wholeBrain;
    listFiles = dir([sub_path '/swar*.nii']);
    for iM = 1:length(listFiles)
        [~,tst] = single_nii2mat([sub_path '/' listFiles(iM).name]);
        head(iM,:) = tst(:);
        h = waitbar(iM/length(listFiles));
    end
%     wholeBrain = [size(head,1) size(tst)];
close(h);

function loadMask(hObject, eventdata, handles)
%{
    Load data: .mat-file with 3D array with name 'mask' which contains
    gray-matter mask
%}

global import;
global mask;
global mask_head;
global qntMask;

h = waitbar(0,'Loading the gray-matter mask. Please wait...');
%{
% get the name of variable inside the .mat file (mask)
tt = whos('-file',import.fpath.mask);
% read this variable (4-D matrix) (mask)
varTMP = load(import.fpath.mask,tt.name); % from here we get 'mask'
mask = varTMP.(tt.name);
%}

mask_head=spm_vol(import.fpath.mask); 
mask=spm_read_vols(mask_head);

qntMask = str2double(handles.editMask.String);

maskFlat = find(mask>quantile(mask(:),qntMask));
disp(['Voxels in work: ' mat2str(length(maskFlat))]);

close(h);


function saveWholeBrainLevel(hObject, eventdata, handles)
%{
    Save whole brain level deconvolution results
%}

global estimateWB;
global maskFlat;

[file,path] = uiputfile(['WholeBrain_' date() '.mat'],'Save file name');

% for i=1:size(wB_head,1)
%     wB_head(i).fname=fullfile(path,file);
%     spm_write_vol(wB_head(i),estimateWB(:,:,:,i));    
% end;
save([path file],'estimateWB','maskFlat');


function calculateForBrainLevel(hObject, eventdata, handles)
%{
    Calculation of the deconvolution on a whole brain level using DS
%}

global wholeBrain;
global mask;
global parameterF;
global hrf;
global parameter;
global estimateWB;
global SC;
global method;

global head;
global maskFlat;
global TR;
global qntMask; 

parameterF = parameter;
parameterF.hrf = hrf;

popupmenuDecMethod_Callback(hObject, eventdata, handles);
popupmenuSC_Callback(hObject, eventdata, handles);

maskFlat = find(mask>quantile(mask(:),qntMask));
% disp(['Voxels in work: ' mat2str(length(maskFlat))]);

h = waitbar(0,'Calculation for whole brain level. Please, wait...');

[b,a] = butter(2, 1/128/(1/TR),'high');
% estimateWB = zeros([size(head,1), size(mask,1),size(mask,2),size(mask,3)]);

for iSbj = 1:length(maskFlat)

    yF = filtfilt(b,a,head(:,maskFlat(iSbj)));
    y = nrmlzHRF(yF,min(hrf),max(hrf));
    eWB(:,iSbj) = calculateEstimate(y,method,SC,parameterF);
    
    h = waitbar(iSbj/length(maskFlat));
end;

for iP = 1:size(eWB,1)
    estWB = zeros(size(mask));
    estWB(maskFlat(1:length(eWB(iP,:)))) = eWB(iP,:);
    estimateWB(iP,:,:,:) = estWB;
end
close(h);




function eWB = calculateEstimate(y,method,SC,parameterF)
%{
    Make calculations for signal y.
%}

global parameter;
global hrf;

parameterF = parameter;
parameterF.hrf = hrf;
H = ToeplitzMatrix(hrf,length(y));


% possible estimates
switch method
case 'DS'
    parameterF.stopEarlier = 1;
    [estSet, lambdaset.DS] = decDSset(y, H, parameterF);
    
    bestIndexA = parameterSelection(y,estSet,H,0);
    bestIndexB = parameterSelection(y,estSet,H,1);
    
    finalEstimate.DS.MCI = selectEstimate(estSet,'MT',lambdaset.DS);
    finalEstimate.DS.AIC = selectEstimate(estSet,'AIC',bestIndexA);
    finalEstimate.DS.BIC = selectEstimate(estSet,'BIC',bestIndexB);
    finalEstimate.DS.AllPeaks = selectEstimate(estSet,'AllP',length(y));

case 'LASSO'
    [estSet, lambdaset.LASSO] = decLASSOset(y,H);
        
    bestIndexA = parameterSelection(y,estSet,H,0);
    bestIndexB = parameterSelection(y,estSet,H,1);
    
    finalEstimate.LASSO.MCI = selectEstimate(estSet,'MT',lambdaset.LASSO);
    finalEstimate.LASSO.AIC = selectEstimate(estSet,'AIC',bestIndexA);
    finalEstimate.LASSO.BIC = selectEstimate(estSet,'BIC',bestIndexB);
    finalEstimate.LASSO.AllPeaks = selectEstimate(estSet,'AllP',length(y));
end;
eWB = finalEstimate.(method).(SC);


% --- Executes on button press in checkboxDefKern.
function checkboxDefKern_Callback(hObject, eventdata, handles)
% hObject    handle to checkboxDefKern (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkboxDefKern



function editRT_Callback(hObject, eventdata, handles)
% hObject    handle to editRT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editRT as text
%        str2double(get(hObject,'String')) returns contents of editRT as a double


% --- Executes during object creation, after setting all properties.
function editRT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editRT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editMask_Callback(hObject, eventdata, handles)
% hObject    handle to editMask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMask as text
%        str2double(get(hObject,'String')) returns contents of editMask as a double


% --- Executes during object creation, after setting all properties.
function editMask_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
