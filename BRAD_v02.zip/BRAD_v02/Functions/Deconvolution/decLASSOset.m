function [estLASSOset, lambdaset] = decLASSOset(output,H1)
% Find the LASSO-estimate for the signals output (output 1D-vector!!)
% For choosing of one particular signal we're using the minimum of
% residuals

% Toeplitz matrix


y = output;
%[estLASSOset,fitInfo] = lasso(H1,y);
%lambdaset = fitInfo.Lambda;

[beta, A, mu, C, c, gamma] = lars_2(H1, y, 'lasso', Inf, 0);

estLASSOset0 = beta';
lambdaset0 = [0 arrayfun(@(k)sum(gamma(1:k)),1:length(gamma))];
estLASSOset = estLASSOset0(:,end:-1:1);
lambdaset = lambdaset0(end:-1:1);

end