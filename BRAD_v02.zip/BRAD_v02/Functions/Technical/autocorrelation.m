function [acf] = autocorrelation(x, demonstration)
% AutoCorrelation Function
% x - input signal (vector)
% demonstration = 'Y' (yes) or 'N' (no)

correlationFunction = @(h,k) sum((h(1:(length(h)-k))-mean(h)).*(h((k+1):length(h))-mean(h)))/sum((h-mean(h)).^2);

autocorrelation = @(h) arrayfun(@(k) correlationFunction(h,k),0:(length(h)-1));

acf = autocorrelation(x);

if strcmp(demonstration,'Y')
    plot(acf);
    title('AutoCorrelation Function');
end;

end