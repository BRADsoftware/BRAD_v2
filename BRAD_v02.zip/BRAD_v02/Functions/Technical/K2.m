function [k] = K2(x)
% kernel function K2 - gaussian kernel
k = 1/sqrt(2*pi)*exp(-1/2*x^2);
end