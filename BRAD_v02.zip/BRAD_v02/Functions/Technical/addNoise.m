function [yn] = addNoise(y,lvlSigma)
% Add white noise with level lvlSigma*maximal amplitude of signal y

yn = y + lvlSigma*(max(y)-min(y))*randn(size(y));
end