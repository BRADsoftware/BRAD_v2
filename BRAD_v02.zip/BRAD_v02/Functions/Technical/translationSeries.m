function [newVector] = translationSeries(vector,step)
% moving vector on step

newVector = [vector(step:end),vector(1:step-1)];

end