function [nlv] = noiseLevelHRf(spectr,hrf)

[vB,spB] = fittingSpectrumPiHRf(spectr, hrf);
nlv = vB(2);

end