function [spectr] = signalSpectrum(y,nP)
    Yf = fft(y,2*nP);
    spectr = abs(Yf).^2;
    spectr = spectr(1:nP);
end